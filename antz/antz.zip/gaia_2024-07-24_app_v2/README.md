
Feel free to contact us: https://gaiaviz.com

- <a href="https://openantz/download/msw/">DOWNLOAD (MS Windows) - GaiaViz.exe desktop app</a>

3rd party licenses and helpful resources are in the 'doc' folder.

To get orientated see: <a href="https://github.com/GaiaViz/GaiaViz/wiki/User-Commands/">Wiki - User Commands</a>


----
GaiaViz Copyright 2024, Shane Saxon. GaiaViz desktop app is licensed under CC BY-ND 4.0.

GaiaViz is a registered trademark. All trademarks are property of their respective owners.

